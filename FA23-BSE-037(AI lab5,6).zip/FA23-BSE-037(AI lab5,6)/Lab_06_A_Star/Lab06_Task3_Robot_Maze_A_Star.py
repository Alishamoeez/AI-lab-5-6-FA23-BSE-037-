# Standalone file for Lab06_Task3_Robot_Maze_A_Star.py
# COMSATS University Islamabad, Wah Campus
# Artificial Intelligence - Lab 05 / Lab 06
# Run: python Lab06_Task3_Robot_Maze_A_Star.py

# Name : Hadiqa Akbar
# ID   : SP23-BSE-007  (COMSATS University Islamabad, Wah Campus)
# Course: Artificial Intelligence - Lab 05 (GBFS) and Lab 06 (A*)
#
# Run:  python Hadiqa_AI_Lab5_Lab6.py
# (Lab 5 Task 3 asks for input; just press Enter to use the sample puzzle.)

import heapq
import math
from collections import deque


def banner(text):
    print("\n" + "=" * 64)
    print(text)
    print("=" * 64)


# =====================================================================
#                              LAB 05
# =====================================================================
LAB5_GRAPH = {
    'A': ['B', 'C'], 'B': ['D', 'E'], 'C': ['F'],
    'D': ['G'], 'E': ['G'], 'F': ['G'], 'G': [],
}
HEURISTIC_1 = {'A': 7, 'B': 5, 'C': 3, 'D': 4, 'E': 2, 'F': 1, 'G': 0}
HEURISTIC_2 = {'A': 7, 'B': 2, 'C': 5, 'D': 1, 'E': 3, 'F': 2, 'G': 0}


def greedy_best_first(graph, h, start, goal):
    frontier = [start]
    visited = set()
    order = []
    while frontier:
        current = min(frontier, key=lambda n: h[n])
        frontier.remove(current)
        order.append(current)
        print(current)
        if current == goal:
            print("Goal found!")
            return order
        visited.add(current)
        for nb in graph[current]:
            if nb not in visited and nb not in frontier:
                frontier.append(nb)
    return None


def lab5_activity1():
    banner("LAB 5 - Activity 1: GBFS with the given heuristic")
    order = greedy_best_first(LAB5_GRAPH, HEURISTIC_1, 'A', 'G')
    print("Nodes explored:", " -> ".join(order))


def lab5_activity2():
    banner("LAB 5 - Activity 2: GBFS with changed heuristic")
    order = greedy_best_first(LAB5_GRAPH, HEURISTIC_2, 'A', 'G')
    print("Nodes explored (new heuristic):", " -> ".join(order))
    print("Nodes explored (old heuristic): A -> C -> F -> G")
    print("Discussion: graph same hai, sirf h(n) badla, is liye search ka "
          "raasta badal gaya (A-C-F-G se A-B-D-G). Matlab informed search "
          "ka behaviour heuristic par depend karta hai.")


def manhattan_distance(current, goal):
    return abs(current[0] - goal[0]) + abs(current[1] - goal[1])


def lab5_task1():
    banner("LAB 5 - Task 1: Manhattan distance heuristic")
    goal = (4, 4)
    positions = [(0, 0), (1, 2), (2, 3), (3, 4), (4, 4)]
    for p in positions:
        print(f"h{p} = |{goal[0]}-{p[0]}| + |{goal[1]}-{p[1]}| = "
              f"{manhattan_distance(p, goal)}")


# ---------------- 8-puzzle helpers (0 = blank) ----------------
GOAL = (1, 2, 3, 4, 5, 6, 7, 8, 0)


def misplaced(state):
    return sum(1 for i, t in enumerate(state) if t != 0 and t != GOAL[i])


def neighbours(state):
    blank = state.index(0)
    r, c = divmod(blank, 3)
    result = []
    for dr, dc in ((-1, 0), (1, 0), (0, -1), (0, 1)):
        nr, nc = r + dr, c + dc
        if 0 <= nr < 3 and 0 <= nc < 3:
            lst = list(state)
            j = nr * 3 + nc
            lst[blank], lst[j] = lst[j], lst[blank]
            result.append(tuple(lst))
    return result


def is_solvable(state):
    tiles = [t for t in state if t != 0]
    inversions = sum(1 for i in range(len(tiles))
                     for j in range(i + 1, len(tiles)) if tiles[i] > tiles[j])
    return inversions % 2 == 0   # 3x3 board: even inversions => solvable


def show_state(state):
    for i in range(0, 9, 3):
        print("   " + " ".join(str(t) if t else "_" for t in state[i:i + 3]))


def build_path(parent, state):
    path = []
    while state is not None:
        path.append(state)
        state = parent[state]
    return path[::-1]


def puzzle_gbfs(start):
    counter = 0
    heap = [(misplaced(start), counter, start)]
    parent = {start: None}
    closed = set()
    while heap:
        _, _, cur = heapq.heappop(heap)
        if cur in closed:
            continue
        closed.add(cur)
        if cur == GOAL:
            return build_path(parent, cur), len(closed)
        for nb in neighbours(cur):
            if nb not in parent:
                parent[nb] = cur
                counter += 1
                heapq.heappush(heap, (misplaced(nb), counter, nb))
    return None, len(closed)


def print_solution(path):
    for step, st in enumerate(path):
        print(f"Step {step}  (h = {misplaced(st)})")
        show_state(st)
    print("Total steps in solution:", len(path) - 1)


def lab5_task2():
    banner("LAB 5 - Task 2: 8-puzzle using GBFS")
    start = (1, 2, 3, 4, 0, 6, 7, 5, 8)
    path, explored = puzzle_gbfs(start)
    print_solution(path)
    print("States explored:", explored)


def read_puzzle():
    print("Enter 9 numbers (0 = blank) separated by spaces, e.g. "
          "1 2 3 4 0 6 7 5 8")
    raw = input("Start state (Enter for default): ").strip()
    if not raw:
        return (1, 2, 3, 4, 0, 6, 7, 5, 8)

    try:
        nums = tuple(int(x) for x in raw.split())
    except ValueError:
        print("Invalid input: enter integers from 0 to 8 only.")
        return None

    if len(nums) != 9 or sorted(nums) != list(range(9)):
        print("Invalid input: enter each number from 0 to 8 exactly once.")
        return None
    return nums


def lab5_task3():
    banner("LAB 5 - Task 3: 8-puzzle with user input + solvability check")
    start = read_puzzle()
    if start is None:
        return
    print("Initial state:")
    show_state(start)
    if not is_solvable(start):
        print("Puzzle is NOT solvable (inversion count is odd).")
        return
    print("Puzzle is solvable (inversion count is even). Searching...")
    path, explored = puzzle_gbfs(start)
    print_solution(path)
    print("States explored:", explored)


# =====================================================================
#                              LAB 06
# =====================================================================
def diagonal_distance(current, goal):
    return max(abs(current[0] - goal[0]), abs(current[1] - goal[1]))


def euclidean_distance(current, goal):
    return math.sqrt((goal[0] - current[0]) ** 2 + (goal[1] - current[1]) ** 2)


def lab6_activity1():
    banner("LAB 6 - Activity 1: Heuristic functions")
    cur, goal = (1, 1), (4, 8)
    print("Manhattan :", manhattan_distance(cur, goal))
    print("Diagonal  :", diagonal_distance(cur, goal))
    print("Euclidean :", euclidean_distance(cur, goal))


MAZE_NODES = {
    'A': (0, 0), 'B': (2, 0), 'C': (3, 0), 'D': (4, 0), 'E': (5, 0),
    'F': (0, 1), 'G': (2, 1), 'H': (0, 2), 'I': (1, 2), 'J': (2, 2),
    'K': (4, 2), 'L': (5, 2), 'M': (0, 3), 'N': (1, 3), 'O': (3, 3),
    'P': (4, 3), 'Q': (5, 3), 'R': (0, 4), 'S': (1, 4), 'T': (2, 4),
    'U': (3, 4), 'V': (5, 4), 'W': (2, 5), 'X': (4, 5), 'Y': (5, 5),
}


def maze_graph():
    """Neighbours are generated automatically from the coordinates."""
    by_pos = {pos: name for name, pos in MAZE_NODES.items()}
    g = {}
    for name, (x, y) in MAZE_NODES.items():
        g[name] = [by_pos[p] for p in ((x, y + 1), (x, y - 1), (x - 1, y), (x + 1, y))
                   if p in by_pos]
    return g


def lab6_activity2():
    banner("LAB 6 - Activity 2: Maze path planning (A*)")
    graph = maze_graph()
    goal = 'Y'
    h = lambda n: manhattan_distance(MAZE_NODES[n], MAZE_NODES[goal])

    heap = [(h('A'), 'A')]
    g_cost = {'A': 0}
    parent = {'A': None}
    closed = set()
    while heap:
        f, cur = heapq.heappop(heap)
        if cur in closed:
            continue
        print(f"Node: {cur} g = {g_cost[cur]} h = {h(cur)} f = {f}")
        if cur == goal:
            break
        closed.add(cur)
        for nb in graph[cur]:
            ng = g_cost[cur] + 1
            if nb not in g_cost or ng < g_cost[nb]:
                g_cost[nb] = ng
                parent[nb] = cur
                heapq.heappush(heap, (ng + h(nb), nb))
    path = []
    n = goal
    while n is not None:
        path.append(n)
        n = parent[n]
    path.reverse()
    print("\nFinal Path:", path)
    print("Total Path Cost:", len(path) - 1)


# ---------------- Lab Task 1: Romania ----------------
ROMANIA = {
    'Arad': {'Zerind': 75, 'Sibiu': 140, 'Timisoara': 118},
    'Zerind': {'Arad': 75, 'Oradea': 71},
    'Oradea': {'Zerind': 71, 'Sibiu': 151},
    'Sibiu': {'Arad': 140, 'Oradea': 151, 'Fagaras': 99, 'Rimnicu Vilcea': 80},
    'Timisoara': {'Arad': 118, 'Lugoj': 111},
    'Lugoj': {'Timisoara': 111, 'Mehadia': 70},
    'Mehadia': {'Lugoj': 70, 'Dobreta': 75},
    'Dobreta': {'Mehadia': 75, 'Craiova': 120},
    'Craiova': {'Dobreta': 120, 'Rimnicu Vilcea': 146, 'Pitesti': 138},
    'Rimnicu Vilcea': {'Sibiu': 80, 'Craiova': 146, 'Pitesti': 97},
    'Fagaras': {'Sibiu': 99, 'Bucharest': 211},
    'Pitesti': {'Rimnicu Vilcea': 97, 'Craiova': 138, 'Bucharest': 101},
    'Bucharest': {'Fagaras': 211, 'Pitesti': 101, 'Urziceni': 85, 'Giurgiu': 90},
    'Giurgiu': {'Bucharest': 90},
    'Urziceni': {'Bucharest': 85, 'Hirsova': 98, 'Vaslui': 142},
    'Hirsova': {'Urziceni': 98, 'Eforie': 86},
    'Eforie': {'Hirsova': 86},
    'Vaslui': {'Urziceni': 142, 'Iasi': 92},
    'Iasi': {'Vaslui': 92, 'Neamt': 87},
    'Neamt': {'Iasi': 87},
}
SLD = {
    'Arad': 366, 'Bucharest': 0, 'Craiova': 160, 'Dobreta': 242, 'Eforie': 161,
    'Fagaras': 176, 'Giurgiu': 77, 'Hirsova': 151, 'Iasi': 226, 'Lugoj': 244,
    'Mehadia': 241, 'Neamt': 234, 'Oradea': 380, 'Pitesti': 100,
    'Rimnicu Vilcea': 193, 'Sibiu': 253, 'Timisoara': 329, 'Urziceni': 80,
    'Vaslui': 199, 'Zerind': 374,
}


def best_first_cost(graph, start, goal, h):
    """A* when h = SLD, Uniform Cost Search when h = 0. Returns path, cost, expanded."""
    heap = [(h(start), 0, start)]
    best_g = {start: 0}
    parent = {start: None}
    closed = set()
    expanded = []
    while heap:
        f, g, cur = heapq.heappop(heap)
        if cur in closed:
            continue
        closed.add(cur)
        expanded.append(cur)
        if cur == goal:
            path = []
            while cur:
                path.append(cur)
                cur = parent[cur]
            return path[::-1], g, expanded
        for nb, w in graph[cur].items():
            ng = g + w
            if nb not in best_g or ng < best_g[nb]:
                best_g[nb] = ng
                parent[nb] = cur
                heapq.heappush(heap, (ng + h(nb), ng, nb))
    return None, None, expanded


def bfs(graph, start, goal):
    queue = deque([start])
    parent = {start: None}
    expanded = []
    while queue:
        cur = queue.popleft()
        expanded.append(cur)
        if cur == goal:
            path = []
            while cur:
                path.append(cur)
                cur = parent[cur]
            return path[::-1], expanded
        for nb in graph[cur]:
            if nb not in parent:
                parent[nb] = cur
                queue.append(nb)
    return None, expanded


def road_cost(path):
    return sum(ROMANIA[a][b] for a, b in zip(path, path[1:]))


def lab6_task1():
    banner("LAB 6 - Task 1: A* on Arad -> Bucharest + comparison")
    p, c, ex = best_first_cost(ROMANIA, 'Arad', 'Bucharest', lambda n: SLD[n])
    print("A*  path :", " -> ".join(p))
    print("A*  cost :", c, "km | nodes expanded:", len(ex))
    print("A*  order:", ex)

    p2, c2, ex2 = best_first_cost(ROMANIA, 'Arad', 'Bucharest', lambda n: 0)
    print("\nUCS path :", " -> ".join(p2))
    print("UCS cost :", c2, "km | nodes expanded:", len(ex2))

    p3, ex3 = bfs(ROMANIA, 'Arad', 'Bucharest')
    print("\nBFS path :", " -> ".join(p3))
    print("BFS cost :", road_cost(p3), "km | nodes expanded:", len(ex3))

    print("\nImprovements noticed:")
    print(f"1) A* ne sirf {len(ex)} nodes expand kiye, UCS ne {len(ex2)} aur "
          f"BFS ne {len(ex3)}.")
    print(f"2) A* ne optimal path ({c} km) mila, jabke BFS ne kam hops wala "
          f"lekin mehnga path ({road_cost(p3)} km) diya.")
    print("3) Heuristic (straight-line distance) search ko Bucharest ki taraf "
          "guide karti hai, is liye ghair zaroori shehron ki taraf nahi jata.")


# ---------------- Lab Task 2: 8-puzzle with A* ----------------
def puzzle_astar(start):
    counter = 0
    heap = [(misplaced(start), 0, counter, start)]
    g_cost = {start: 0}
    parent = {start: None}
    closed = set()
    while heap:
        f, g, _, cur = heapq.heappop(heap)
        if cur in closed:
            continue
        closed.add(cur)
        if cur == GOAL:
            return build_path(parent, cur), g, len(closed)
        for nb in neighbours(cur):
            ng = g + 1                       # every tile move costs 1
            if nb not in g_cost or ng < g_cost[nb]:
                g_cost[nb] = ng
                parent[nb] = cur
                counter += 1
                heapq.heappush(heap, (ng + misplaced(nb), ng, counter, nb))
    return None, None, len(closed)


def lab6_task2():
    banner("LAB 6 - Task 2: 8-puzzle using A*")
    for start in [(1, 2, 3, 4, 0, 6, 7, 5, 8), (8, 1, 3, 4, 0, 2, 7, 6, 5)]:
        if not is_solvable(start):
            print("Not solvable:", start)
            continue
        path, cost, explored = puzzle_astar(start)
        for i, st in enumerate(path):
            g = i
            h = misplaced(st)
            print(f"Step {i}: g = {g}, h = {h}, f = {g + h}")
            show_state(st)
        print("Total cost:", cost, "| states explored:", explored, "\n")


# ---------------- Lab Task 3: Robot maze ----------------
# '#' = wall, '.' = free, S = start (red), G = goal (green).
# Coordinates are (row, col). NOTE: grid below is read from the figure in
# the lab manual. If any cell differs from your manual, just edit it here.
MAZE = [
    "S...#.....",
    "..#...##..",
    "...#..##.#",
    ".#..#...##",
    ".##.......",
    ".#..###.##",
    "#..###....",
    ".###......",
    "#.###...#G",
]
DIRS = [(-1, 0), (0, 1), (1, 0), (0, -1)]          # N, E, S, W
DIR_NAMES = ["North", "East", "South", "West"]


def find_cell(ch):
    for r, row in enumerate(MAZE):
        if ch in row:
            return (r, row.index(ch))


def maze_free(r, c):
    return 0 <= r < len(MAZE) and 0 <= c < len(MAZE[0]) and MAZE[r][c] != '#'


def lab6_task3():
    banner("LAB 6 - Task 3: Robot maze using A*")
    start, goal = find_cell('S'), find_cell('G')
    h = lambda pos: manhattan_distance(pos, goal)
    # state = (row, col, facing). Turn = cost 1, moving k cells forward = cost k
    s0 = (start[0], start[1], 1)                       # robot starts facing East
    heap = [(h(start), 0, 0, s0)]
    g_cost = {s0: 0}
    parent = {s0: (None, "start")}
    closed = set()
    tie = 0
    final = None
    while heap:
        f, g, _, st = heapq.heappop(heap)
        if st in closed:
            continue
        closed.add(st)
        r, c, d = st
        if (r, c) == goal:
            final = st
            break
        moves = [((r, c, (d + 1) % 4), 1, "turn right"),
                 ((r, c, (d - 1) % 4), 1, "turn left")]
        k = 1
        while maze_free(r + DIRS[d][0] * k, c + DIRS[d][1] * k):
            nr, nc = r + DIRS[d][0] * k, c + DIRS[d][1] * k
            moves.append(((nr, nc, d), k, f"move {DIR_NAMES[d]} {k}"))
            k += 1
        for ns, cost, label in moves:
            ng = g + cost
            if ns not in g_cost or ng < g_cost[ns]:
                g_cost[ns] = ng
                parent[ns] = (st, label)
                tie += 1
                heapq.heappush(heap, (ng + h(ns[:2]), ng, tie, ns))
    if final is None:
        print("No path found.")
        return
    steps = []
    st = final
    while st is not None:
        prev, label = parent[st]
        steps.append((st, label))
        st = prev
    steps.reverse()
    print("Actions taken:")
    for st, label in steps[1:]:
        print(f"  {label:<15} -> now at ({st[0]}, {st[1]}) facing {DIR_NAMES[st[2]]}")
    coords = [steps[0][0][:2]]
    for st, _ in steps[1:]:
        if st[:2] != coords[-1]:
            coords.append(st[:2])
    print("\nPath (row, col):", coords)
    print("Total cost:", g_cost[final])


if __name__ == "__main__":
    lab6_task3()
